const faunadb = require('faunadb');
const q = faunadb.query;

exports.handler = async (event, context) => {
    try {
        // Проверка аутентификации
        const user = context.clientContext.user;
        if (!user) {
            return {
                statusCode: 401,
                body: JSON.stringify({ error: 'Unauthorized' })
            };
        }
        
        // Инициализация FaunaDB
        const client = new faunadb.Client({
            secret: process.env.FAUNADB_SECRET
        });
        
        // Получаем всех пользователей из Netlify Identity
        // В реальном приложении нужно синхронизировать с FaunaDB
        const result = await client.query(
            q.Map(
                q.Paginate(q.Documents(q.Collection('users'))),
                q.Lambda('ref', q.Get(q.Var('ref')))
            )
        );
        
        return {
            statusCode: 200,
            body: JSON.stringify(result.data.map(doc => doc.data))
        };
        
    } catch (error) {
        return {
            statusCode: 500,
            body: JSON.stringify({ error: error.message })
        };
    }
};