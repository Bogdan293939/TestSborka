const faunadb = require('faunadb');
const q = faunadb.query;

exports.handler = async (event, context) => {
    try {
        const user = context.clientContext.user;
        if (!user) {
            return {
                statusCode: 401,
                body: JSON.stringify({ error: 'Unauthorized' })
            };
        }
        
        const client = new faunadb.Client({
            secret: process.env.FAUNADB_SECRET
        });
        
        const data = JSON.parse(event.body || '{}');
        
        if (event.httpMethod === 'GET' || data.action === 'get') {
            // Получение сообщений
            const messages = await client.query(
                q.Map(
                    q.Paginate(
                        q.Intersection(
                            q.Match(q.Index('messages_by_participants'), [
                                user.email,
                                data.recipient || null
                            ]),
                            q.Match(q.Index('messages_by_participants'), [
                                data.recipient || null,
                                user.email
                            ])
                        ),
                        { size: 50 }
                    ),
                    q.Lambda('ref', q.Get(q.Var('ref')))
                )
            );
            
            return {
                statusCode: 200,
                body: JSON.stringify(messages.data.map(doc => doc.data))
            };
            
        } else if (data.action === 'send') {
            // Отправка сообщения
            const message = {
                sender: user.email,
                recipient: data.recipient || null,
                text: data.text,
                timestamp: new Date().toISOString()
            };
            
            await client.query(
                q.Create(q.Collection('messages'), {
                    data: message
                })
            );
            
            return {
                statusCode: 200,
                body: JSON.stringify({ success: true })
            };
        }
        
    } catch (error) {
        return {
            statusCode: 500,
            body: JSON.stringify({ error: error.message })
        };
    }
};