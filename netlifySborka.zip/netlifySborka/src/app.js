class Messenger {
    constructor() {
        this.currentUser = null;
        this.selectedUser = null;
        this.messageQueue = [];
        
        this.init();
    }
    
    async init() {
        // Инициализация Netlify Identity
        if (window.netlifyIdentity) {
            window.netlifyIdentity.on("init", (user) => {
                this.handleAuth(user);
            });
            
            window.netlifyIdentity.on("login", (user) => {
                this.handleAuth(user);
                window.netlifyIdentity.close();
            });
            
            window.netlifyIdentity.on("logout", () => {
                this.handleLogout();
            });
            
            window.netlifyIdentity.init();
        }
        
        document.getElementById('logout-btn').addEventListener('click', () => {
            window.netlifyIdentity.logout();
        });
        
        document.getElementById('send-btn').addEventListener('click', () => {
            this.sendMessage();
        });
        
        document.getElementById('message-input').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.sendMessage();
            }
        });
    }
    
    async handleAuth(user) {
        if (user) {
            this.currentUser = user;
            document.getElementById('auth-screen').classList.add('hidden');
            document.getElementById('chat-screen').classList.remove('hidden');
            
            // Получаем токен для API
            const token = await window.netlifyIdentity.currentUser().jwt();
            this.token = token;
            
            // Загружаем пользователей и сообщения
            await this.loadUsers();
            await this.loadMessages();
            
            // Запускаем SSE соединение для реального времени
            this.startSSE();
        }
    }
    
    handleLogout() {
        this.currentUser = null;
        document.getElementById('auth-screen').classList.remove('hidden');
        document.getElementById('chat-screen').classList.add('hidden');
        
        if (this.eventSource) {
            this.eventSource.close();
        }
    }
    
    async loadUsers() {
        try {
            const response = await fetch('/.netlify/functions/users', {
                headers: {
                    'Authorization': `Bearer ${this.token}`
                }
            });
            
            const users = await response.json();
            this.displayUsers(users);
        } catch (error) {
            console.error('Error loading users:', error);
        }
    }
    
    displayUsers(users) {
        const userList = document.getElementById('user-list');
        userList.innerHTML = '';
        
        // Добавляем общий чат
        const generalChat = document.createElement('div');
        generalChat.className = 'user-item active';
        generalChat.textContent = '💬 Общий чат';
        generalChat.onclick = () => this.selectUser(null);
        userList.appendChild(generalChat);
        
        // Добавляем других пользователей
        users.forEach(user => {
            if (user.email !== this.currentUser.email) {
                const userElement = document.createElement('div');
                userElement.className = 'user-item';
                userElement.textContent = `👤 ${user.email}`;
                userElement.onclick = () => this.selectUser(user);
                userList.appendChild(userElement);
            }
        });
    }
    
    selectUser(user) {
        this.selectedUser = user;
        
        // Обновляем активный элемент в списке
        document.querySelectorAll('.user-item').forEach(item => {
            item.classList.remove('active');
        });
        
        event.target.classList.add('active');
        
        // Обновляем заголовок чата
        const chatWith = document.getElementById('chat-with');
        chatWith.textContent = user ? `Чат с ${user.email}` : 'Общий чат';
        
        // Загружаем историю сообщений
        this.loadMessages();
    }
    
    async loadMessages() {
        try {
            const response = await fetch('/.netlify/functions/messages', {
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                    'Content-Type': 'application/json'
                },
                method: 'POST',
                body: JSON.stringify({
                    recipient: this.selectedUser?.email
                })
            });
            
            const messages = await response.json();
            this.displayMessages(messages);
        } catch (error) {
            console.error('Error loading messages:', error);
        }
    }
    
    displayMessages(messages) {
        const messagesContainer = document.getElementById('messages');
        messagesContainer.innerHTML = '';
        
        messages.forEach(message => {
            const messageElement = document.createElement('div');
            messageElement.className = `message ${
                message.sender === this.currentUser.email ? 'own' : 'other'
            }`;
            
            const time = new Date(message.timestamp).toLocaleTimeString();
            messageElement.innerHTML = `
                <div class="message-text">${message.text}</div>
                <div class="message-meta">
                    <small>${message.sender} • ${time}</small>
                </div>
            `;
            
            messagesContainer.appendChild(messageElement);
        });
        
        // Прокручиваем вниз
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
    
    async sendMessage() {
        const input = document.getElementById('message-input');
        const text = input.value.trim();
        
        if (!text) return;
        
        try {
            const response = await fetch('/.netlify/functions/messages', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    action: 'send',
                    text: text,
                    recipient: this.selectedUser?.email
                })
            });
            
            if (response.ok) {
                input.value = '';
                await this.loadMessages();
            }
        } catch (error) {
            console.error('Error sending message:', error);
        }
    }
    
    startSSE() {
        // Server-Sent Events для реального времени
        this.eventSource = new EventSource(`/.netlify/functions/sse?token=${this.token}`);
        
        this.eventSource.onmessage = (event) => {
            const data = JSON.parse(event.data);
            
            if (data.type === 'new_message') {
                // Проверяем, относится ли сообщение к текущему чату
                const isRelevant = !data.message.recipient || 
                    data.message.sender === this.selectedUser?.email ||
                    (!this.selectedUser && !data.message.recipient);
                
                if (isRelevant) {
                    this.loadMessages();
                }
            }
        };
        
        this.eventSource.onerror = (error) => {
            console.error('SSE error:', error);
            setTimeout(() => this.startSSE(), 5000);
        };
    }
}

// Запуск приложения
document.addEventListener('DOMContentLoaded', () => {
    new Messenger();
});